import fetch from "node-fetch";

export default async function handler(req, res) {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "Method not allowed" });
    }

    const { message, history } = req.body;

    const messages = [
      {
        role: "system",
        content: "Tu es MIRA, une assistante intelligente, naturelle et fiable."
      },
      ...(history || []).slice(-10),
      { role: "user", content: message }
    ];

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "llama-3.1-8b-instant",
        messages: messages
      })
    });

    const data = await response.json();
    const reply = data?.choices?.[0]?.message?.content || "Erreur";

    res.status(200).json({ reply });

  } catch (error) {
    res.status(500).json({ error: "Erreur serveur" });
  }
}
